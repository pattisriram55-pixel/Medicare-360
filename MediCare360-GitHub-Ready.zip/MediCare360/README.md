# MediCare 360 — Smart Hospital Management System

A responsive, front-end hospital management dashboard built with **HTML5, CSS3, and vanilla JavaScript**. The interface is designed for desktop, tablet, and mobile screens.

## Features

- Dashboard with patient, appointment, doctor, and pending-payment summaries
- Patient registration and patient list search
- Appointment booking, status tracking, and cancellation
- Doctor and department directory
- Invoice creation and payment-status tracking
- Pharmacy inventory and low-stock indicators
- Basic operational reports with CSV export
- Browser-based persistence using `localStorage`
- Responsive navigation for mobile screens

## Project structure

```text
MediCare360/
├── index.html       # Complete website (HTML, CSS, and JavaScript)
├── README.md        # Project documentation
├── .gitignore       # Files to exclude from Git
└── .nojekyll        # Helps GitHub Pages serve the site without Jekyll processing
```

## Run locally

1. Download or clone this repository.
2. Open the project folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the **Live Server** extension in VS Code.

No npm install or build step is required.

## Publish with GitHub Pages

1. Create a GitHub repository and upload the files in this folder.
2. Open the repository's **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the `main` branch and `/ (root)` folder, then save.
5. Wait for GitHub Pages to publish the site. The public URL will appear in the Pages settings.

## Technology

- HTML5
- CSS3 (responsive media queries)
- Vanilla JavaScript
- Browser `localStorage`

## Important limitations

This repository contains a **front-end academic/demo project**, not a production hospital system.

- Data is stored only in the current browser's `localStorage`; it is not shared between devices or users.
- There is no backend, database, real login, or server-side role-based access control.
- Do not enter real patient records or sensitive medical information.
- The sample names and records are demonstration data.
- A production deployment would need a secure backend, database, authentication, authorization, audit logging, backups, and appropriate privacy/security controls.

## Student project details

- **Project:** MediCare 360 — Smart Hospital Management System
- **Student:** Patti Sriram
- **Enrollment No.:** 25CS003771
- **Branch:** DS (L&T)
- **Semester:** III
